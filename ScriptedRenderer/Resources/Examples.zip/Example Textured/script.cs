using System;
using System.Collections.Generic;
using OpenTK;
using OpenTK.Graphics;
using ScriptedEngine;
using BMEngine;

// Textures provided by YMI Black Moon from his resource packs

public class Script
{
    public string Description = "An example of a basic textured script, with note caps and shadows around black keys. Textures provided by YMI Black Moon.";
    public string Preview = "preview.png";

    // Define texture variables
    Texture keyBlack;
    Texture keyBlackPressed;
    Texture keyWhite;
    Texture keyWhitePressed;
    Texture noteBody;
    Texture noteTop;
    Texture noteBottom;

    public void Load()
    {
        // Load textures
        keyBlack = IO.LoadTexture("keyBlack.png");
        keyBlackPressed = IO.LoadTexture("keyBlackPressed.png");
        keyWhite = IO.LoadTexture("keyWhite.png");
        keyWhitePressed = IO.LoadTexture("keyWhitePressed.png");
        noteBody = IO.LoadTexture("note.png");
        noteTop = IO.LoadTexture("noteTop.png");
        noteBottom = IO.LoadTexture("noteBottom.png");
    }

    public void Render(IEnumerable<Note> notes, RenderOptions options)
    {
        double keyboardHeight = 0.15;
        // Adjust height based on keyboard range
        keyboardHeight = keyboardHeight / (options.lastKey - options.firstKey) * 128;
        // Adjust height based on screen aspect ratio
        keyboardHeight = keyboardHeight / (1920.0 / 1080.0) * options.renderAspectRatio;

        // The variables below are used to convert notes from tick positions to screen position
        // It's calculated here rather than each time a note is drawn for optimization
        double notePosFactor = 1 / options.noteScreenTime * (1 - keyboardHeight);
        double renderCutoff = options.midiTime + options.noteScreenTime;

        // The keyboard layout, each key's and note's left and right edges as well as some other metadata
        var layout = Util.GetKeyboardLayout(options.firstKey, options.lastKey, new KeyboardOptions());
        // The colors of each key. 512 instead of 256 because gradients.
        var keyColors = new Color4[512];
        var keyPressed = new bool[256];

        // Loop over each note
        foreach (var note in Util.BlackNotesAbove(notes))
        {
            // If a note is above or below the view, skip it.
            if (note.hasEnded && note.end < options.midiTime || note.start > renderCutoff) continue;

            // Get the coordinates of the note's edges
            double top = 1 - (renderCutoff - note.end) * notePosFactor;
            double bottom = 1 - (renderCutoff - note.start) * notePosFactor;
            double left = layout.keys[note.key].left;
            double right = layout.keys[note.key].right;
            // If a note hasn't ended, set it's top coordinate to the top of the screen
            if (!note.hasEnded) top = 1;

            // Calculate cap sizes and position
            double topCapHeight = (right - left) / noteTop.aspectRatio * options.renderAspectRatio;
            double bottomCapHeight = (right - left) / noteBottom.aspectRatio * options.renderAspectRatio;
            double capTop = top - topCapHeight;
            double capBottom = bottom + bottomCapHeight;
            // If note smaller than caps, make the note bigger to fit caps
            if (capTop < capBottom)
            {
                capTop = (capTop + capBottom) / 2;
                capBottom = capTop;
                top = capTop + topCapHeight;
                bottom = capBottom - bottomCapHeight;
            }

            Color4 leftCol = note.color.left;
            Color4 rightCol = note.color.right;

            // Check if the note is touching the keyboard
            if (note.start < options.midiTime)
            {
                // Mark key as pressed
                keyPressed[note.key] = true;

                // If it is, blend the current key's color with the note color
                // Blending is useful if the notes are semi-transparent
                keyColors[note.key * 2] = Util.BlendColors(keyColors[note.key * 2], note.color.left);
                keyColors[note.key * 2 + 1] = Util.BlendColors(keyColors[note.key * 2 + 1], note.color.right);

                // Lighten the note color for hit notes
                leftCol = Util.BlendColors(leftCol, new Color4(255, 255, 255, 70));
                rightCol = Util.BlendColors(rightCol, new Color4(255, 255, 255, 70));
            }

            if (layout.blackKey[note.key])
            {
                // Darken black notes
                leftCol = Util.BlendColors(leftCol, new Color4(0, 0, 0, 70));
                rightCol = Util.BlendColors(rightCol, new Color4(0, 0, 0, 70));
            }

            // Render the note body and note caps, with gradient color
            IO.RenderQuad(left, capTop, right, capBottom, leftCol, rightCol, rightCol, leftCol, noteBody);
            IO.RenderQuad(left, top, right, capTop, leftCol, rightCol, rightCol, leftCol, noteTop);
            IO.RenderQuad(left, capBottom, right, bottom, leftCol, rightCol, rightCol, leftCol, noteBottom);
        }

        // If the start/end keys are black, render an extra white key next to them
        int firstKey = options.firstKey;
        int lastKey = options.lastKey;
        if (layout.blackKey[firstKey]) firstKey--;
        if (layout.blackKey[lastKey - 1]) lastKey++;

        for (int i = firstKey; i < lastKey; i++)
        {
            // Only render white keys
            if (!layout.blackKey[i])
            {
                Color4 leftCol = Util.BlendColors(new Color4(255, 255, 255, 255), keyColors[i * 2]);
                Color4 rightCol = Util.BlendColors(new Color4(255, 255, 255, 255), keyColors[i * 2 + 1]);

                if (keyPressed[i])
                {
                    IO.RenderQuad(layout.keys[i].left, keyboardHeight, layout.keys[i].right, 0, leftCol, leftCol, rightCol, rightCol, keyWhitePressed);
                }
                else
                {
                    IO.RenderQuad(layout.keys[i].left, keyboardHeight, layout.keys[i].right, 0, leftCol, leftCol, rightCol, rightCol, keyWhite);
                }
            }
        }

        for (int i = firstKey; i < lastKey; i++)
        {
            // Only render black keys
            if (layout.blackKey[i])
            {
                Color4 leftCol = Util.BlendColors(new Color4(255, 255, 255, 255), keyColors[i * 2]);
                Color4 rightCol = Util.BlendColors(new Color4(255, 255, 255, 255), keyColors[i * 2 + 1]);

                // Change the width of the key to also include shadow
                double left = layout.keys[i].left;
                double right = layout.keys[i].right;
                double width = right - left;
                left -= width * 0.7;
                right += width * 0.7;

                if (keyPressed[i])
                {
                    IO.RenderQuad(left, keyboardHeight, right, keyboardHeight / 3, leftCol, leftCol, rightCol, rightCol, keyBlackPressed);
                }
                else
                {
                    IO.RenderQuad(left, keyboardHeight, right, keyboardHeight / 3, leftCol, leftCol, rightCol, rightCol, keyBlack);
                }
            }
        }
    }
}