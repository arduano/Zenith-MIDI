using System;
using System.Collections.Generic;
using OpenTK;
using OpenTK.Graphics;
using ScriptedEngine;
using BMEngine;

public class Script
{
    public string Description = "An extremely basic script, but supporting all main features (custom keyboard range, transparent and gradient notes)";
    public string Preview = "preview.png";

    public void Load()
    {
        // This script doesn't require any loading    
    }

    public void Render(IEnumerable<Note> notes, RenderOptions options)
    {
        double keyboardHeight = 0.15;

        // The variables below are used to convert notes from tick positions to screen position
        // It's calculated here rather than each time a note is drawn for optimization
        double notePosFactor = 1 / options.noteScreenTime * (1 - keyboardHeight);
        double renderCutoff = options.midiTime + options.noteScreenTime;

        // The keyboard layout, each key's and note's left and right edges as well as some other metadata
        var layout = Util.GetKeyboardLayout(options.firstKey, options.lastKey, new KeyboardOptions());

        // The colors of each key. 512 instead of 256 because gradients.
        var keyColors = new Color4[512];

        // Loop over each note
        foreach (var note in Util.BlackNotesAbove(notes))
        {
            // If a note is above or below the view, skip it.
            if (note.hasEnded && note.end < options.midiTime || note.start > renderCutoff) continue;

            // Get the coordinates of the note's edges
            double top = 1 - (renderCutoff - note.end) * notePosFactor;
            double bottom = 1 - (renderCutoff - note.start) * notePosFactor;
            double left = layout.keys[note.key].left;
            double right = layout.keys[note.key].right;
            // If a note hasn't ended, set it's top coordinate to the top of the screen
            if (!note.hasEnded) top = 1;

            // Render the note, with gradient color
            IO.RenderQuad(left, top, right, bottom, note.color.left, note.color.right, note.color.right, note.color.left);

            // Check if the note is touching the keyboard
            if (note.start < options.midiTime)
            {
                // If it is, blend the current key's color with the note color
                // Blending is useful if the notes are semi-transparent
                keyColors[note.key * 2] = Util.BlendColors(keyColors[note.key * 2], note.color.left);
                keyColors[note.key * 2 + 1] = Util.BlendColors(keyColors[note.key * 2 + 1], note.color.right);
            }
        }

        // If the start/end keys are black, render an extra white key next to them
        int firstKey = options.firstKey;
        int lastKey = options.lastKey;
        if (layout.blackKey[firstKey]) firstKey--;
        if (layout.blackKey[lastKey - 1]) lastKey++;

        for (int i = firstKey; i < lastKey; i++)
        {
            // Only render white keys
            if (!layout.blackKey[i])
            {
                Color4 leftCol = Util.BlendColors(new Color4(255, 255, 255, 255), keyColors[i * 2]);
                Color4 rightCol = Util.BlendColors(new Color4(255, 255, 255, 255), keyColors[i * 2 + 1]);
                IO.RenderQuad(layout.keys[i].left, keyboardHeight, layout.keys[i].right, 0, leftCol, leftCol, rightCol, rightCol);
            }
        }

        for (int i = firstKey; i < lastKey; i++)
        {
            // Only render black keys
            if (layout.blackKey[i])
            {
                Color4 leftCol = Util.BlendColors(new Color4(50, 50, 50, 255), keyColors[i * 2]);
                Color4 rightCol = Util.BlendColors(new Color4(50, 50, 50, 255), keyColors[i * 2 + 1]);
                IO.RenderQuad(layout.keys[i].left, keyboardHeight, layout.keys[i].right, keyboardHeight / 2.7, leftCol, leftCol, rightCol, rightCol);
            }
        }
    }
}